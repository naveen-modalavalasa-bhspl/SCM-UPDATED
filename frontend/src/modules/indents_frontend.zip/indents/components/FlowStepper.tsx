import { Check, Circle, Clock, Minus, X } from "lucide-react";
import type { IndentJourney, IndentJourneyStage } from "../types";

type StepState = "completed" | "current" | "pending" | "rejected" | "skipped" | "unknown";

interface SummaryStep {
  key: string;
  label: string;
  state: StepState;
  caption?: string;
}

const REVIEW_SLOTS = [
  { key: "oe", label: "OE Review" },
  { key: "dm", label: "DM Review" },
  { key: "rm", label: "RM Review" },
] as const;

const POST_APPROVAL_STATUSES = new Set([
  "APPROVED",
  "AWAITING_ALLOCATION",
  "ALLOCATED",
  "PARTIALLY_FULFILLED",
  "PENDING_PROCUREMENT",
  "PARTIALLY_ORDERED",
  "ORDERED",
  "CLOSED",
]);

function formatFinalLabel(title?: string | null) {
  if (!title) return "Final Approval - SPH/COO";
  return title
    .replace(/\s*-\s*/g, " - ")
    .replace(/\bor\b/gi, "/")
    .replace(/\s*\/\s*/g, "/");
}

function classifyReviewStage(stage: IndentJourneyStage) {
  const text = `${stage.title} ${stage.position_name ?? ""}`.toUpperCase();
  if (/\bOE\b|OPERATION EXECUTIVE|OPERATIONS EXECUTIVE/.test(text)) return "oe";
  if (/\bDM\b|DISTRICT MANAGER/.test(text)) return "dm";
  if (/\bRM\b|REGIONAL MANAGER/.test(text)) return "rm";
  return null;
}

function stateFromStage(stage?: IndentJourneyStage): StepState {
  if (!stage) return "skipped";
  if (stage.status === "REJECTED") return "rejected";
  if (stage.status === "NOT_REQUIRED") return "skipped";
  if (stage.is_current) return "current";
  if (stage.status === "APPROVED" || stage.status === "SUBMITTED") return "completed";
  if (stage.status === "PENDING") return "pending";
  return "unknown";
}

function isApprovalComplete(status: string) {
  return POST_APPROVAL_STATUSES.has(status);
}

function buildReviewSteps(journey: IndentJourney | undefined, status: string): SummaryStep[] {
  const approvalStages = (journey?.stages ?? [])
    .filter((stage) => stage.stage_type === "approval")
    .sort((a, b) => a.sequence - b.sequence);
  const bySlot = new Map<string, IndentJourneyStage>();
  const unclassified: IndentJourneyStage[] = [];

  approvalStages.forEach((stage) => {
    const slot = classifyReviewStage(stage);
    if (slot && !bySlot.has(slot)) {
      bySlot.set(slot, stage);
    } else {
      unclassified.push(stage);
    }
  });

  REVIEW_SLOTS.forEach((slot) => {
    if (bySlot.has(slot.key)) return;
    const next = unclassified.shift();
    if (next) bySlot.set(slot.key, next);
  });

  return REVIEW_SLOTS.map((slot) => {
    const stage = bySlot.get(slot.key);
    const state = stateFromStage(stage);
    return {
      key: slot.key,
      label: stage?.title ?? slot.label,
      state: isApprovalComplete(status) && stage && state !== "skipped" ? "completed" : state,
      caption: stage ? statusCaption(state) : "Not required",
    };
  });
}

function statusCaption(state: StepState) {
  const captions: Record<StepState, string> = {
    completed: "Completed",
    current: "Current",
    pending: "Pending",
    rejected: "Rejected",
    skipped: "Not required",
    unknown: "Status unavailable",
  };
  return captions[state];
}

function buildSteps(status: string, journey?: IndentJourney): SummaryStep[] | null {
  if (status === "DRAFT") {
    return [
      { key: "draft", label: "Draft", state: "current", caption: "Current" },
      { key: "submitted", label: "Submitted", state: "pending", caption: "Pending" },
      ...REVIEW_SLOTS.map((slot) => ({ key: slot.key, label: slot.label, state: "pending" as const, caption: "Pending" })),
      { key: "final", label: "Final Approval - SPH/COO", state: "pending", caption: "Pending" },
    ];
  }

  if (!journey && !["PENDING_APPROVAL", "REJECTED"].includes(status) && !isApprovalComplete(status)) {
    return null;
  }

  const requestStage = journey?.stages.find((stage) => stage.stage_type === "request");
  const finalStage = journey?.stages.find((stage) => stage.stage_type === "final");
  const requestState = stateFromStage(requestStage);
  const reviewSteps = buildReviewSteps(journey, status);
  const finalState = stateFromStage(finalStage);
  const steps: SummaryStep[] = [
    { key: "draft", label: "Draft", state: "completed", caption: "Completed" },
    {
      key: "submitted",
      label: "Submitted",
      state: requestState === "rejected" ? "rejected" : "completed",
      caption: requestState === "rejected" ? "Rejected" : "Completed",
    },
    ...reviewSteps,
    {
      key: "final",
      label: formatFinalLabel(finalStage?.title),
      state: isApprovalComplete(status) && finalStage?.status !== "NOT_REQUIRED"
        ? "completed"
        : finalState === "skipped"
          ? "pending"
          : finalState,
      caption: finalState === "skipped" && !isApprovalComplete(status) ? "Pending" : statusCaption(
        isApprovalComplete(status) && finalStage?.status !== "NOT_REQUIRED" ? "completed" : finalState,
      ),
    },
  ];

  const rejectedIndex = steps.findIndex((step) => step.state === "rejected");
  if (rejectedIndex >= 0) {
    return steps.map((step, index) => {
      if (index <= rejectedIndex) return step;
      return { ...step, state: step.state === "skipped" ? "skipped" : "pending", caption: step.state === "skipped" ? "Not required" : "Pending" };
    });
  }
  return steps;
}

function iconFor(state: StepState, index: number) {
  if (state === "completed") return <Check className="h-3.5 w-3.5" />;
  if (state === "current") return <Clock className="h-3.5 w-3.5" />;
  if (state === "rejected") return <X className="h-3.5 w-3.5" />;
  if (state === "skipped") return <Minus className="h-3.5 w-3.5" />;
  if (state === "unknown") return <Circle className="h-3.5 w-3.5" />;
  return index + 1;
}

function stateClasses(state: StepState) {
  const classes: Record<StepState, string> = {
    completed: "border-ok bg-ok text-white",
    current: "border-brand bg-brand text-white shadow-sm shadow-brand/20",
    pending: "border-line bg-white text-muted",
    rejected: "border-bad bg-bad text-white",
    skipped: "border-line bg-content2 text-muted",
    unknown: "border-bad/40 bg-bad-bg text-bad",
  };
  return classes[state];
}

function connectorClass(left: StepState, right: StepState) {
  if (left === "completed" && right !== "rejected") return "bg-ok";
  if (left === "rejected") return "bg-line";
  return "bg-line";
}

export function FlowStepper({ status, journey }: { status: string; journey?: IndentJourney }) {
  const steps = buildSteps(status, journey);
  if (!steps) {
    return (
      <div className="rounded-md border border-bad/30 bg-bad-bg px-3 py-2 text-sm font-medium text-bad">
        Status unavailable
      </div>
    );
  }

  return (
    <div className="-mx-1 overflow-x-auto px-1 pb-1" aria-label="Compact approval progress">
      <ol className="grid min-w-[720px] grid-cols-6 items-start gap-0 md:min-w-0" data-testid="compact-approval-progress">
        {steps.map((step, index) => (
          <li key={step.key} className="relative flex min-w-0 flex-col items-center px-1 text-center">
            {index > 0 && (
              <span
                className={`absolute left-0 top-4 h-0.5 w-1/2 -translate-y-1/2 ${connectorClass(steps[index - 1].state, step.state)}`}
                aria-hidden="true"
              />
            )}
            {index < steps.length - 1 && (
              <span
                className={`absolute right-0 top-4 h-0.5 w-1/2 -translate-y-1/2 ${connectorClass(step.state, steps[index + 1].state)}`}
                aria-hidden="true"
              />
            )}
            <span
              aria-label={`${step.label}: ${step.caption ?? statusCaption(step.state)}`}
              className={`relative z-10 grid h-8 w-8 place-items-center rounded-full border text-xs font-bold transition-colors ${stateClasses(step.state)}`}
            >
              {iconFor(step.state, index)}
            </span>
            <span className={`mt-2 min-h-8 max-w-28 text-balance break-words text-[11px] font-semibold leading-4 ${
              step.state === "skipped" || step.state === "pending" ? "text-muted" : "text-body"
            }`}>
              {step.label}
            </span>
            {step.caption && (
              <span className="mt-0.5 text-[10px] font-medium leading-3 text-muted">{step.caption}</span>
            )}
          </li>
        ))}
      </ol>
    </div>
  );
}
