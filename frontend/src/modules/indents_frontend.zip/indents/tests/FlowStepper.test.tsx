import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { FlowStepper } from "../components/FlowStepper";
import type { IndentJourney, IndentJourneyStage } from "../types";

function stage(overrides: Partial<IndentJourneyStage>): IndentJourneyStage {
  return {
    sequence: 1,
    title: "Stage",
    status: "PENDING",
    stage_type: "approval",
    ...overrides,
  };
}

function journey(stages: IndentJourneyStage[], status = "PENDING_APPROVAL"): IndentJourney {
  return {
    indent_id: 42,
    indent_no: "IND/42",
    status,
    requested_by_name: "Requester",
    created_at: "2026-07-27T09:30:00Z",
    current_stage_message: "In approval",
    stages,
    history: [],
  };
}

const request = stage({
  sequence: 1,
  title: "Request Raised",
  status: "SUBMITTED",
  stage_type: "request",
});

function approvalJourney(overrides: Partial<Record<"oe" | "dm" | "rm" | "final", Partial<IndentJourneyStage>>>, status = "PENDING_APPROVAL") {
  return journey([
    request,
    stage({
      sequence: 2,
      title: "OE Review",
      status: "PENDING",
      is_current: true,
      ...overrides.oe,
    }),
    stage({
      sequence: 3,
      title: "DM Review",
      status: "PENDING",
      ...overrides.dm,
    }),
    stage({
      sequence: 4,
      title: "RM Review",
      status: "PENDING",
      ...overrides.rm,
    }),
    stage({
      sequence: 5,
      title: "Final Approval - SPH or COO",
      status: "PENDING",
      stage_type: "final",
      ...overrides.final,
    }),
  ], status);
}

describe("FlowStepper", () => {
  it("shows Draft current for draft indents", () => {
    render(<FlowStepper status="DRAFT" />);

    expect(screen.getByLabelText("Draft: Current")).toHaveClass("bg-brand");
    expect(screen.getByLabelText("Submitted: Pending")).toHaveClass("border-line");
    expect(screen.getByLabelText("Final Approval - SPH/COO: Pending")).toBeInTheDocument();
  });

  it("marks OE Review current after requester submits", () => {
    render(<FlowStepper status="PENDING_APPROVAL" journey={approvalJourney({})} />);

    expect(screen.getByLabelText("Draft: Completed")).toHaveClass("bg-ok");
    expect(screen.getByLabelText("Submitted: Completed")).toHaveClass("bg-ok");
    expect(screen.getByLabelText("OE Review: Current")).toHaveClass("bg-brand");
    expect(screen.getByLabelText("DM Review: Pending")).toHaveClass("border-line");
  });

  it("marks DM Review current after OE approval", () => {
    render(<FlowStepper status="PENDING_APPROVAL" journey={approvalJourney({
      oe: { status: "APPROVED", is_current: false },
      dm: { status: "PENDING", is_current: true },
    })} />);

    expect(screen.getByLabelText("OE Review: Completed")).toHaveClass("bg-ok");
    expect(screen.getByLabelText("DM Review: Current")).toHaveClass("bg-brand");
    expect(screen.getByLabelText("RM Review: Pending")).toHaveClass("border-line");
  });

  it("marks RM Review current after DM approval", () => {
    render(<FlowStepper status="PENDING_APPROVAL" journey={approvalJourney({
      oe: { status: "APPROVED", is_current: false },
      dm: { status: "APPROVED", is_current: false },
      rm: { status: "PENDING", is_current: true },
    })} />);

    expect(screen.getByLabelText("DM Review: Completed")).toHaveClass("bg-ok");
    expect(screen.getByLabelText("RM Review: Current")).toHaveClass("bg-brand");
  });

  it("marks final SPH/COO approval current after RM approval", () => {
    render(<FlowStepper status="PENDING_APPROVAL" journey={approvalJourney({
      oe: { status: "APPROVED", is_current: false },
      dm: { status: "APPROVED", is_current: false },
      rm: { status: "APPROVED", is_current: false },
      final: { status: "PENDING", is_current: true },
    })} />);

    expect(screen.getByLabelText("RM Review: Completed")).toHaveClass("bg-ok");
    expect(screen.getByLabelText("Final Approval - SPH/COO: Current")).toHaveClass("bg-brand");
  });

  it("shows completed approval for awaiting allocation", () => {
    render(<FlowStepper status="AWAITING_ALLOCATION" journey={approvalJourney({
      oe: { status: "APPROVED", is_current: false },
      dm: { status: "APPROVED", is_current: false },
      rm: { status: "APPROVED", is_current: false },
      final: { status: "APPROVED", is_current: false },
    }, "AWAITING_ALLOCATION")} />);

    expect(screen.getByLabelText("Draft: Completed")).toHaveClass("bg-ok");
    expect(screen.getByLabelText("Submitted: Completed")).toHaveClass("bg-ok");
    expect(screen.getByLabelText("OE Review: Completed")).toHaveClass("bg-ok");
    expect(screen.getByLabelText("DM Review: Completed")).toHaveClass("bg-ok");
    expect(screen.getByLabelText("RM Review: Completed")).toHaveClass("bg-ok");
    expect(screen.getByLabelText("Final Approval - SPH/COO: Completed")).toHaveClass("bg-ok");
  });

  it("marks rejected stage red and later stages grey", () => {
    render(<FlowStepper status="REJECTED" journey={approvalJourney({
      oe: { status: "APPROVED", is_current: false },
      dm: { status: "REJECTED", is_current: false },
      rm: { status: "PENDING", is_current: false },
    }, "REJECTED")} />);

    expect(screen.getByLabelText("DM Review: Rejected")).toHaveClass("bg-bad");
    expect(screen.getByLabelText("RM Review: Pending")).toHaveClass("border-line");
    expect(screen.getByLabelText("Final Approval - SPH/COO: Pending")).toHaveClass("border-line");
  });

  it("shows skipped requester hierarchy stages as not required", () => {
    render(<FlowStepper status="PENDING_APPROVAL" journey={journey([
      request,
      stage({
        sequence: 2,
        title: "RM Review",
        status: "PENDING",
        is_current: true,
      }),
      stage({
        sequence: 3,
        title: "Final Approval - SPH or COO",
        status: "PENDING",
        stage_type: "final",
      }),
    ])} />);

    expect(screen.getByLabelText("OE Review: Not required")).toHaveClass("bg-content2");
    expect(screen.getByLabelText("DM Review: Not required")).toHaveClass("bg-content2");
    expect(screen.getByLabelText("RM Review: Current")).toHaveClass("bg-brand");
  });

  it("does not silently fall back for unknown statuses", () => {
    render(<FlowStepper status="SOMETHING_NEW" />);
    expect(screen.getByText("Status unavailable")).toBeInTheDocument();
    expect(screen.queryByText("Draft")).not.toBeInTheDocument();
  });

  it("does not render corrupted dash characters in the final approval label", () => {
    render(<FlowStepper status="PENDING_APPROVAL" journey={approvalJourney({})} />);

    expect(screen.getByText("Final Approval - SPH/COO")).toBeInTheDocument();
    expect(screen.queryByText(/â|Ã/)).not.toBeInTheDocument();
  });

  it("uses a horizontally scrollable compact layout for narrow screens", () => {
    render(<FlowStepper status="PENDING_APPROVAL" journey={approvalJourney({})} />);

    expect(screen.getByLabelText("Compact approval progress")).toHaveClass("overflow-x-auto");
    expect(screen.getByTestId("compact-approval-progress")).toHaveClass("grid-cols-6", "min-w-[720px]");
  });
});
