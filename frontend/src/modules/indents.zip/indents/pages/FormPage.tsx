import { useEffect, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { CardBody, Skeleton } from "@heroui/react";
import { PageHeader, Button, Card, Field, Input, Select } from "@/shared/components";
import { useAuth } from "@/shared/auth/AuthContext";
import {
  indentApi, indentKeys, isIndentModuleQuery, masterApi,
  useIndentAccountCacheIsolation, useIndentAccountScope,
} from "../api";
import { ItemCombobox } from "../components/ItemCombobox";
import type { IndentCreate, IndentUpdate } from "../types";

interface Line {
  item_id: number | "";
  quantity: number | "";
  duplicateItemId?: number;
}

const PAST_REQUIRED_DATE_ERROR = "Required date cannot be earlier than today";
const REQUIRED_DATE_MANDATORY_ERROR = "Required date is mandatory.";
const DUPLICATE_ITEM_ERROR = "This item is already added to the indent.";
const MISSING_QTY_ERROR = "Quantity is required for this item.";
const UOM_UNAVAILABLE = "UOM unavailable";

function localDateString(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function duplicateItemRows(lines: Line[]) {
  const seen = new Set<number>();
  const duplicates = new Map<number, number>();
  lines.forEach((line, index) => {
    if (line.item_id === "") return;
    const itemId = Number(line.item_id);
    if (seen.has(itemId)) duplicates.set(index, itemId);
    seen.add(itemId);
  });
  return duplicates;
}

function clearResolvedDuplicateErrors(lines: Line[]) {
  return lines.map((line, index) => {
    if (
      line.duplicateItemId === undefined
      || lines.some((other, otherIndex) =>
        otherIndex !== index && other.item_id === line.duplicateItemId)
    ) {
      return line;
    }
    const validLine = { ...line };
    delete validLine.duplicateItemId;
    return validLine;
  });
}

export function IndentFormPage() {
  const nav = useNavigate();
  const [searchParams] = useSearchParams();
  const editParam = searchParams.get("edit");
  const editId = editParam === null ? null : Number(editParam);
  const isEditing = editId !== null && Number.isFinite(editId);
  const { me } = useAuth();
  const accountScope = useIndentAccountScope();
  useIndentAccountCacheIsolation(accountScope);
  const qc = useQueryClient();
  const initializedDraftId = useRef<number | null>(null);
  const [priority, setPriority] = useState("NORMAL");
  const [requiredDate, setRequiredDate] = useState("");
  const [remarks, setRemarks] = useState("");
  const [deliveryOfficeId, setDeliveryOfficeId] = useState<number | "">(
    me?.active_position?.office_id ?? me?.employee.office_id ?? "",
  );
  const [lines, setLines] = useState<Line[]>([{ item_id: "", quantity: "" }]);
  const [error, setError] = useState<string | null>(null);
  const [hasAttemptedSubmit, setHasAttemptedSubmit] = useState(false);
  const today = localDateString();
  const requiredDateError = !requiredDate
    ? REQUIRED_DATE_MANDATORY_ERROR
    : requiredDate < today
      ? PAST_REQUIRED_DATE_ERROR
      : null;
  const visibleRequiredDateError = hasAttemptedSubmit ? requiredDateError : null;

  const { data: items = [] } = useQuery({
    queryKey: indentKeys.items(accountScope, "form"),
    queryFn: () => masterApi.items(),
  });

  const { data: offices = [] } = useQuery({
    queryKey: indentKeys.offices(accountScope),
    queryFn: () => indentApi.offices(),
    enabled: isEditing,
  });

  const {
    data: draft,
    isLoading: isDraftLoading,
    error: draftLoadError,
  } = useQuery({
    queryKey: indentKeys.detail(accountScope, editId ?? 0),
    queryFn: () => indentApi.get(editId!),
    enabled: isEditing,
  });

  useEffect(() => {
    if (!draft || draft.status !== "DRAFT" || initializedDraftId.current === draft.id) return;
    initializedDraftId.current = draft.id;
    setPriority(draft.priority || "NORMAL");
    setRequiredDate(draft.required_date ?? "");
    setRemarks(draft.remarks ?? "");
    setDeliveryOfficeId(draft.office_id ?? "");
    setLines(draft.items.map((item) => ({
      item_id: item.item_id,
      quantity: Number(item.quantity),
    })));
  }, [draft]);

  const payload = (): IndentCreate => ({
    priority,
    required_date: requiredDate || null,
    remarks: remarks || null,
    items: lines
      .filter((l) => l.item_id !== "" && l.quantity !== "" && Number(l.quantity) > 0)
      .map((l) => ({ item_id: Number(l.item_id), quantity: Number(l.quantity) })),
  });

  const updatePayload = (): IndentUpdate => ({
    ...payload(),
    office_id: deliveryOfficeId === "" ? null : Number(deliveryOfficeId),
  });

  const save = useMutation({
    mutationFn: () => isEditing
      ? indentApi.update(editId!, updatePayload())
      : indentApi.create(payload()),
    onSuccess: (indent) => {
      qc.invalidateQueries({ predicate: isIndentModuleQuery });
      nav(`/indents/${indent.id}`);
    },
    onError: (e: Error) => setError(e.message),
  });

  const setLine = (i: number, patch: Partial<Line>) =>
    setLines((current) => clearResolvedDuplicateErrors(
      current.map((line, index) => (index === i ? { ...line, ...patch } : line)),
    ));
  const setLineItem = (i: number, value: number | "") =>
    setLines((current) => {
      if (
        value !== ""
        && current.some((line, index) => index !== i && line.item_id === value)
      ) {
        return current.map((line, index) =>
          index === i ? { ...line, duplicateItemId: value } : line);
      }
      const updated: Line[] = current.map((line, index) => {
        if (index !== i) return line;
        const validLine = { ...line };
        delete validLine.duplicateItemId;
        return value === ""
          ? { ...validLine, item_id: "", quantity: "" }
          : { ...validLine, item_id: value };
      });
      return clearResolvedDuplicateErrors(updated);
    });
  const rejectDuplicateItem = (i: number, itemId: number) =>
    setLines((current) => current.map((line, index) =>
      index === i ? { ...line, duplicateItemId: itemId } : line));
  const removeLine = (i: number) =>
    setLines((current) => clearResolvedDuplicateErrors(
      current.filter((_, index) => index !== i),
    ));
  const hasSelectedItems = lines.some((line) => line.item_id !== "");
  const duplicateRows = duplicateItemRows(lines);
  const hasDuplicateError = duplicateRows.size > 0
    || lines.some((line) => line.duplicateItemId !== undefined);
  // A row is missing its quantity when an item is selected but qty is empty, zero, or negative.
  const missingQtyRows = new Set<number>(
    lines
      .map((line, i) => ({ line, i }))
      .filter(({ line }) => line.item_id !== "" && (line.quantity === "" || Number(line.quantity) <= 0))
      .map(({ i }) => i),
  );
  const hasMissingQtyError = missingQtyRows.size > 0;

  const itemOptions = items.map((it) => ({ value: it.id, label: `${it.code} — ${it.name}` }));
  const deliveryOptions = isEditing
    ? [
        ...(draft?.office_id && !offices.some((office) => office.id === draft.office_id)
          ? [{ id: draft.office_id, name: draft.office_name ?? "Current office" }]
          : []),
        ...offices,
      ].map((office) => ({ value: office.id, label: office.name }))
    : deliveryOfficeId ? [{
        value: deliveryOfficeId,
        label: me?.active_position?.office_name ?? me?.employee.office_name ?? "Tagged office",
      }] : [];

  if (isEditing && isDraftLoading) return <Skeleton className="h-40 rounded-2xl" />;

  if (isEditing && (draftLoadError || !draft)) {
    return (
      <Card>
        <CardBody className="gap-4 p-5">
          <p className="text-sm font-semibold text-bad">
            {draftLoadError instanceof Error ? draftLoadError.message : "Could not load this indent."}
          </p>
          <Button variant="secondary" onClick={() => nav(`/indents/${editId}`)}>Back to indent</Button>
        </CardBody>
      </Card>
    );
  }

  if (isEditing && draft?.status !== "DRAFT") {
    return (
      <Card>
        <CardBody className="gap-4 p-5">
          <p className="text-sm font-semibold text-body">Only Draft indents can be edited.</p>
          <Button variant="secondary" onClick={() => nav(`/indents/${editId}`)}>Back to indent</Button>
        </CardBody>
      </Card>
    );
  }

  return (
    <>
      <PageHeader
        eyebrow="Indents"
        title={isEditing ? `Edit ${draft?.indent_no ?? "indent"}` : "New request"}
      />

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardBody className="p-5">
            <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-muted">Line items</h2>
            <div className="space-y-3">
              {lines.map((line, i) => {
                const selectedItem = items.find((it) => Number(it.id) === Number(line.item_id));
                const duplicateItemId = line.duplicateItemId ?? duplicateRows.get(i);
                const duplicateErrorId = `indent-item-${i}-duplicate-error`;
                const missingQtyErrorId = `indent-item-${i}-qty-error`;
                const showMissingQtyError = hasAttemptedSubmit && missingQtyRows.has(i);
                const uom = selectedItem?.uom_code?.trim() || (selectedItem ? UOM_UNAVAILABLE : "");
                const quantityLabel = selectedItem
                  ? `Quantity (${uom})`
                  : "Quantity";
                const rowItemOptions = itemOptions.map((option) => ({
                  ...option,
                  isDisabled: option.value !== line.item_id
                    && lines.some((other, otherIndex) =>
                      otherIndex !== i && other.item_id === option.value),
                }));
                return (
                  <div key={i}>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_120px_44px] sm:items-end">
                      <Field label={i === 0 ? "Item" : ""}>
                        <ItemCombobox
                          placeholder="Type item code or name…"
                          value={line.item_id}
                          onChange={(value) => setLineItem(i, value)}
                          onDisabledSelect={(itemId) => rejectDuplicateItem(i, itemId)}
                          options={rowItemOptions}
                          isInvalid={duplicateItemId !== undefined}
                          errorId={duplicateErrorId}
                        />
                      </Field>
                      <Field label={i === 0 ? "Qty" : ""}>
                        <Input
                          type="number"
                          min={0}
                          step="0.001"
                          aria-label={quantityLabel}
                          aria-invalid={showMissingQtyError ? "true" : undefined}
                          aria-describedby={showMissingQtyError ? missingQtyErrorId : undefined}
                          disabled={line.item_id === ""}
                          placeholder={line.item_id === "" ? "—" : undefined}
                          className={line.item_id === "" ? "[&_input]:text-center" : undefined}
                          value={String(line.quantity)}
                          onChange={(e) => setLine(i, { quantity: e.target.value ? Number(e.target.value) : "" })}
                          isInvalid={showMissingQtyError}
                          {...(uom ? {
                            endContent: (
                              <span
                                className="pointer-events-none inline-flex min-w-[2.5rem] shrink-0 items-center justify-end whitespace-nowrap pl-2 text-xs font-medium text-muted"
                                title={uom}
                              >
                                {uom}
                              </span>
                            ),
                          } : {})}
                        />
                      </Field>
                      <button
                        onClick={() => removeLine(i)}
                        disabled={lines.length === 1}
                        className="grid h-11 w-11 place-items-center rounded-xl text-muted hover:bg-bad-bg hover:text-bad disabled:opacity-30"
                        aria-label="Remove line"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    {duplicateItemId !== undefined && (
                      <div className="mt-1 grid grid-cols-1 gap-3 sm:grid-cols-[1fr_120px_44px]">
                        <span
                          id={duplicateErrorId}
                          className="block text-xs font-medium text-bad"
                        >
                          {DUPLICATE_ITEM_ERROR}
                        </span>
                      </div>
                    )}
                    {showMissingQtyError && (
                      <div className="mt-1 grid grid-cols-1 gap-3 sm:grid-cols-[1fr_120px_44px]">
                        <div />
                        <span
                          id={missingQtyErrorId}
                          className="block text-xs font-medium text-bad"
                        >
                          {MISSING_QTY_ERROR}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            <button
              onClick={() => setLines((ls) => [...ls, { item_id: "", quantity: "" }])}
              className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-brand hover:text-brand-600"
            >
              <Plus className="h-4 w-4" /> Add line
            </button>
          </CardBody>
        </Card>

        <Card className="h-fit">
          <CardBody className="gap-4 p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted">Details</h2>
            <Field label="Priority">
              <Select
                value={priority}
                onChange={(v) => setPriority(v || "NORMAL")}
                options={[{ value: "NORMAL", label: "Normal" }, { value: "URGENT", label: "Urgent" }]}
              />
            </Field>
            <Field label="Required date">
              <Input
                type="date"
                min={today}
                value={requiredDate}
                required
                aria-label="Required date"
                aria-invalid={visibleRequiredDateError ? "true" : undefined}
                aria-describedby={visibleRequiredDateError ? "required-date-error" : undefined}
                isInvalid={Boolean(visibleRequiredDateError)}
                onChange={(e) => setRequiredDate(e.target.value)}
              />
              {visibleRequiredDateError && (
                <span id="required-date-error" className="mt-1 block text-xs font-medium text-bad">
                  {visibleRequiredDateError}
                </span>
              )}
            </Field>
            <Field label="Raised as">
              <Input value={me?.active_position?.name ?? "No position assigned"} disabled />
            </Field>
            <Field label="Delivery location">
              <Select
                placeholder="Office is assigned from your position"
                value={deliveryOfficeId}
                onChange={(value) => setDeliveryOfficeId(value === "" ? "" : Number(value))}
                isDisabled={!isEditing}
                options={deliveryOptions}
              />
            </Field>
            <Field label="Remarks">
              <Input value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Optional" />
            </Field>
          </CardBody>
        </Card>
      </div>

      {error && (
        <div className="mt-4 rounded-xl bg-bad-bg px-4 py-3 text-sm font-medium text-bad">{error}</div>
      )}

      <div className="fixed inset-x-0 bottom-0 z-10 flex gap-3 border-t border-line bg-content1 p-4 pb-[calc(env(safe-area-inset-bottom)+1rem)] md:static md:mt-6 md:justify-end md:border-0 md:bg-transparent md:p-0">
        <Button
          variant="subtle"
          className="flex-1 md:flex-none"
          onClick={() => nav(isEditing ? `/indents/${editId}` : "/indents")}
        >
          Cancel
        </Button>
        <Button
          className="flex-1 md:flex-none"
          disabled={
            !hasSelectedItems
            || hasDuplicateError
            || save.isPending
          }
          onClick={() => {
            setError(null);
            setHasAttemptedSubmit(true);
            if (requiredDateError) return;
            if (hasMissingQtyError) return;
            const duplicates = duplicateItemRows(lines);
            if (duplicates.size) {
              setLines((current) => current.map((line, index) => {
                const duplicateItemId = duplicates.get(index);
                return duplicateItemId === undefined
                  ? line
                  : { ...line, item_id: "", duplicateItemId };
              }));
              return;
            }
            save.mutate();
          }}
        >
          {save.isPending
            ? (isEditing ? "Saving…" : "Creating…")
            : (isEditing ? "Save changes" : "Create indent")}
        </Button>
      </div>
    </>
  );
}
